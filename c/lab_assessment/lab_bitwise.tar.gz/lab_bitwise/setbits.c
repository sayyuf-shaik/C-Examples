#include "header.h"
int setbits (int *snum, int *dnum, int pos, int n)
{

}

