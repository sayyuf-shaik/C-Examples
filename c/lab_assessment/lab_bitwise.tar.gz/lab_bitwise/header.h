#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define BUF 256
#define INT_SIZE (sizeof(int)*8)
#define CHAR_SIZE (sizeof(char))
extern int bitcopy ( int *snum ,int *dnum, int n, int spos, int dpos );
